package exception;

public class YakException extends Exception {
	private static final long serialVersionUID = 1L;
    public YakException(String message) { super(message); }
}
