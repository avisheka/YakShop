package com.aa.xeb.yakshop.model;

public class YakYield {

	double milk = 0;
	int skin = 0;

	public YakYield(double milk, int skin) {
		this.milk = milk;
		this.skin = skin;
	}

	public double getMilk() {
		return milk;
	}

	public void setMilk(double milk) {
		this.milk = milk;
	}

	public int getSkin() {
		return skin;
	}

	public void setSkins(int skin) {
		this.skin = skin;
	}
}
