package com.aa.xeb.yakshop.util;

public class YakUtils {

	public static final String YAK_DIED_MSG = "YAK DIED !!";
	
}
